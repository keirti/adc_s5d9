/* generated configuration header file - do not edit */
#ifndef SF_EL_NX_CFG_H_
#define SF_EL_NX_CFG_H_
#define SF_EL_NX_COMMS_CFG_PARAM_CHECKING_ENABLE (1)
/** Specify MAC address. */
#define SF_EL_NX_CFG_ENET0_MAC_H 0x00002E09
#define SF_EL_NX_CFG_ENET0_MAC_L 0x0A0076C7
#define SF_EL_NX_CFG_ENET1_MAC_H 0x00002E09
#define SF_EL_NX_CFG_ENET1_MAC_L 0x0A0076C8
/** Specify reset pin. */
#define SF_EL_NX_CFG_ENET0_RESET_PIN IOPORT_PORT_08_PIN_06
#define SF_EL_NX_CFG_ENET1_RESET_PIN IOPORT_PORT_08_PIN_06
/** Specify number of descriptors. */
#define NUM_RX_DESC               (8)
#define NUM_TX_DESC               (32)
#define SF_EL_NX_CFG_IRQ_IPL      ((3))
#define NX_IP_HARDWARE_INT_CALLBACK_ENABLED (0)
#endif /* SF_EL_NX_CFG_H_ */
