/* generated configuration header file - do not edit */
#ifndef NX_USER_H_
#define NX_USER_H_
#if (SYNERGY_NOT_DEFINED)
#include "nx_src_user.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_auto_ip_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_dhcp_common_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_dhcp_client_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_dhcp_server_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_dns_client_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_ftp_common_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_ftp_client_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_ftp_server_cfg.h"
#endif
#if (1)
#include "nx_http_common_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_http_client_cfg.h"
#endif
#if (1)
#include "nx_http_server_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_pop3_client_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_ppp_common_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_ppp_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_smtp_client_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_snmp_agent_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_sntp_client_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_telnet_common_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_telnet_client_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_telnet_server_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_tftp_common_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_tftp_client_cfg.h"
#endif
#if (SYNERGY_NOT_DEFINED)
#include "nx_tftp_server_cfg.h"
#endif
#endif /* NX_USER_H_ */
