/* generated configuration header file - do not edit */
#ifndef NX_FTP_COMMON_CFG_H_
#define NX_FTP_COMMON_CFG_H_
#if (!1)
#define  NX_FTP_NO_FILEX
#endif
#define  NX_FTP_CONTROL_TOS                        NX_IP_NORMAL
#define  NX_FTP_DATA_TOS                           NX_IP_NORMAL
#define  NX_FTP_FRAGMENT_OPTION                    NX_DONT_FRAGMENT
#define  NX_FTP_TIME_TO_LIVE                       128
#define  NX_FTP_TIMEOUT_PERIOD                     60
#endif /* NX_FTP_COMMON_CFG_H_ */
