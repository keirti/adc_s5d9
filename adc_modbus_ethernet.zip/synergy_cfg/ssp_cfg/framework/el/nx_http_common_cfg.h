/* generated configuration header file - do not edit */
#ifndef NX_HTTP_COMMON_CFG_H_
#define NX_HTTP_COMMON_CFG_H_
#if (0)
#define NX_HTTP_DIGEST_ENABLE
#endif

#define NX_HTTP_FRAGMENT_OPTION                     NX_DONT_FRAGMENT
#define NX_HTTP_TIME_TO_LIVE                        128
#define NX_HTTP_TYPE_OF_SERVICE                     NX_IP_NORMAL
#define NX_HTTP_MAX_RESOURCE                        40
#endif /* NX_HTTP_COMMON_CFG_H_ */
