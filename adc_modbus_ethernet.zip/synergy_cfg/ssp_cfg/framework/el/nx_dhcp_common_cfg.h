/* generated configuration header file - do not edit */
#ifndef NX_DHCP_COMMON_CFG_H_
#define NX_DHCP_COMMON_CFG_H_
#define NX_DHCP_TYPE_OF_SERVICE                    (NX_IP_NORMAL)
#define NX_DHCP_FRAGMENT_OPTION                    (NX_DONT_FRAGMENT)
#define NX_DHCP_TIME_TO_LIVE                       (128)
#define NX_DHCP_QUEUE_DEPTH                        (5)
#endif /* NX_DHCP_COMMON_CFG_H_ */
