/* generated configuration header file - do not edit */
#ifndef NX_TFTP_COMMON_CFG_H_
#define NX_TFTP_COMMON_CFG_H_
#define NX_TFTP_ERROR_STRING_MAX                    (64)
#define NX_TFTP_TIME_TO_LIVE                        128
#define NX_TFTP_FRAGMENT_OPTION                     NX_DONT_FRAGMENT
#define NX_TFTP_TYPE_OF_SERVICE                     (NX_IP_NORMAL)
#endif /* NX_TFTP_COMMON_CFG_H_ */
