/* generated configuration header file - do not edit */
#ifndef NX_TELNET_COMMON_CFG_H_
#define NX_TELNET_COMMON_CFG_H_
#define NX_TELNET_TOS                                (NX_IP_NORMAL)
#define NX_TELNET_FRAGMENT_OPTION                    (NX_DONT_FRAGMENT)
#define NX_TELNET_SERVER_PORT                        (23)
#define NX_TELNET_TIME_TO_LIVE                       (128)
#endif /* NX_TELNET_COMMON_CFG_H_ */
