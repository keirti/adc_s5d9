/* generated configuration header file - do not edit */
#ifndef R_DTC_CFG_H_
#define R_DTC_CFG_H_
#define DTC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define DTC_CFG_SOFTWARE_START_ENABLE (0)
#define DTC_CFG_VECTOR_TABLE_SECTION_NAME ".ssp_dtc_vector_table"
#endif /* R_DTC_CFG_H_ */
