# adc_s5d9
using periodic framework module(single-scan)
